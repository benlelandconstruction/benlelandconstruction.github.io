<div class="logo"></div>
<div id="menu">
		
		<div class="navlinks">
			<ul>
				<li><a href="index.php" class="home">Home</a></li>
				<li><a href="mercer_island_residence.php" class="gallery">Images of Our Work</a></li>
				<li><a href="who_we_are.php"  class="about">Who We Are</a></li>
				<li><a href="contact.php"  class="contact">Contact Us</a></li>
			</ul>
		</div>
        
        <div class="address" style="">PO Box 2447 Issaquah WA 98027     425-883-3099<br />
© Copyright 2009 Ben Leland Construction. <br />
A division of Hochanadel Homes, Inc.</div>
</div>