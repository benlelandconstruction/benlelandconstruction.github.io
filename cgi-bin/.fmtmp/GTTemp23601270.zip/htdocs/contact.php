<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />
<title>Contact  Ben Leland Construction</title>
<!--[if IE 6]>
<link rel="stylesheet" href="css/supersizedIE6.css" type="text/css" media="screen" />
<link rel="stylesheet" href="theme/supersized.shutter.css" type="text/css" media="screen" />
<link href="css/stylesIE6.css" rel="stylesheet" type="text/css" />		
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/supersized.3.2.7.min.js"></script>
<script type="text/javascript" src="theme/supersized.shutter.min.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script type="text/javascript" src="who_we_are.js"></script>
<![endif]-->

<!--[if IE 7]>
<link rel="stylesheet" href="css/supersized.css" type="text/css" media="screen" />
<link rel="stylesheet" href="theme/supersized.shutter.css" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />		
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/supersized.3.2.7.min.js"></script>
<script type="text/javascript" src="theme/supersized.shutter.min.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script type="text/javascript" src="who_we_are.js"></script>
<![endif]-->

<!--[if gt IE 7]>
<link rel="stylesheet" href="css/supersized.css" type="text/css" media="screen" />
<link rel="stylesheet" href="theme/supersized.shutter.css" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />		
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/supersized.3.2.7.min.js"></script>
<script type="text/javascript" src="theme/supersized.shutter.min.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script type="text/javascript" src="who_we_are.js"></script>
<![endif]-->

<!--[if !IE]><!-->
<link rel="stylesheet" href="css/supersized.css" type="text/css" media="screen" />
<link rel="stylesheet" href="theme/supersized.shutter.css" type="text/css" media="screen" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />		
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.min.js"></script>
<script type="text/javascript" src="js/supersized.3.2.7.min.js"></script>
<script type="text/javascript" src="theme/supersized.shutter.min.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationTextarea.js" type="text/javascript"></script>
<script type="text/javascript" src="who_we_are.js"></script>
 <!--<![endif]-->




<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-30683502-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<body id="contact">
<div id="apDiv1">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="41%" style="text-align:left" valign="top"><h1>Contact Us</h1>
        <p>&nbsp;</p>
        <p> <strong>Address:</strong><br />
          PO Box 2447<br />
          Issaquah WA 98027<br />
          <br />
          <strong>Phone:</strong> 425-883-3099<br />
          <strong>Fax:</strong> 425-883-3066 </p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <h1>Our People</h1>
        <p> </p>
        <p><br />
          <strong>Todd Hochanadel</strong><br />
President/Owner <br />
Email: <a href="mailto:todd@benlelandconstruction.com">todd@benlelandconstruction.com</a> <br />
<br />
<strong>Marlene Hochanadel </strong><br />
Vice President/Owner<br />
Email: <a href="mailto:marlene@benlelandconstruction.com">marlene@benlelandconstruction.com</a><br />
<br />
<strong>Tory Appel </strong><br />
Project Coordination/Client Liaison/Customer Service<br />
Email: <a href="mailto:tory@benlelandconstruction.com">tory@benlelandconstruction.com</a></p>
        <p>&nbsp; </p>
      </td>
        <td width="59%" valign="top">
        <div style="width:90%; text-align:left">
        <p><strong>Send Us a Message</strong></p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <form id="form1" name="form1" method="post" action="http://websightprojects.com/clients/benleland/form_contact.php">
          First Name <span id="sprytextfield1">
          <input type="text" name="fname" id="fname" style="height:20px" />
          <span class="textfieldRequiredMsg">Enter Your First Name</span></span>
          <p><br />Last name 
            <span id="sprytextfield2">
        <label for="text2"></label>
        <input type="text" name="lname" id="lname" style="height:20px"/>
        <span class="textfieldRequiredMsg">Enter Your Last Name</span></span>
          </p>
          <p><br />
          Phone <span id="sprytextfield3">
          <input type="text" name="phone" id="phone" style="height:20px"/>
          <span style="font-size:12px"> (numbers only ex. 0005555555)</span>
          <span class="textfieldRequiredMsg"><br />
          Enter a phone number<br />
          </span><span class="textfieldInvalidFormatMsg"><br />
          Invalid phone format.</span></span></p>
        <p><br />
          Email 
            <span id="sprytextfield4">
            <input type="text" name="email" id="email" style="height:20px"/>
            <span class="textfieldRequiredMsg">Enter an Email Address.</span><span class="textfieldInvalidFormatMsg">Invalid email format.</span></span></p>
        <p>&nbsp;</p>
        <p>Message:<br />
          <span id="sprytextarea1">
          <textarea name="message" id="message" cols="45" rows="5"></textarea>
          <span class="textareaRequiredMsg"><br />
A value is required.</span></span>        <br />
          <br />
          Email to: 
          <label for="select"></label>
          <select name="recipient" id="recipient">
            <option value="all">All</option>
            
            <option value="todd@benlelandconstruction.com">Todd</option>
            <option value="marlene@benlelandconstruction.com">Marlene</option>
            <option value="tory@benlelandconstruction.com">Tory</option>
          
            
           
          </select>
          <br />
        </p>
        <p>
          <br />
          <input type="submit" name="button" id="button" value="Submit" style="padding:5px;" />
        </p>
        </form>
        </div>
        
        </td>
      </tr>
    </table>
  <p>&nbsp;</p>
</div>   
<?php include 'includes/nav.php';?>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "phone_number", {format:"phone_custom", pattern:"0000000000", useCharacterMasking:true});
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4", "email");
var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1", {isRequired:false});
</script>
</body>
</html>
