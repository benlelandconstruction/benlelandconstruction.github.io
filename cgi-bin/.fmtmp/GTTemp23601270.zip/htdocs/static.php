<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Who We Are Ben Leland Construction</title>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery.js"></script>  
<script type="text/javascript" src="supersized.1.0.js"></script>
<script type="text/javascript">
$(function(){  
    $.fn.supersized.options = {  
        startwidth: 1024,  
        startheight: 768,  
        minsize: .5,  
       
    };  
        $('#supersize').supersized();  
});

</script>


</head>

<body>
<div id="supersize">  
       <img class="activeslide" src="images/background/JPEG/LRlengthfireplace.jpg"/>  
       <a href="#"><img src="picture2.jpg"/></a>  
</div> 
<?php include 'includes/nav.php';?>
</body>
</html>
